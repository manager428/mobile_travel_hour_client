

import 'package:flutter/material.dart';

class LockIcon {
  Icon lock = Icon(Icons.lock);
  Icon lockOn = Icon(Icons.lock);
  Icon lockOff = Icon(Icons.lock_open);
}