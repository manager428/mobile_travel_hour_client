
import 'package:flutter/material.dart';



  var textStylicon = TextStyle(
      
      fontSize: 14,
      fontWeight: FontWeight.w500,
      color: Colors.grey[600]);

  var titleTextStyle = TextStyle(
      
      fontSize: 16,
      fontWeight: FontWeight.w700,
      color: Colors.grey[800]);


  var subtitleTextStyle = TextStyle(
      
      fontSize: 13,
      fontWeight: FontWeight.w500,
      color: Colors.grey[500]);


  var textStyleFeaturedtitle = TextStyle(
      
      fontSize: 17,
      fontWeight: FontWeight.w600,
      color: Colors.grey[800]);


