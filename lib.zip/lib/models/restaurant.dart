

class Restaurant {
  String name;
  String address;
  double lat;
  double lng;
  var rating;
  var price;
  bool openingHour;

  Restaurant(this.name, this.address, this.lat, this.lng, this.rating,
  this.price, this.openingHour);
}