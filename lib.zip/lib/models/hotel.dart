
class Hotel {
  String name; 
  String address;
  double lat;
  double lng;
  var rating;
  var price;

  Hotel(this.name,this.address,this.lat,this.lng,this.rating,this.price);
  
  
}