
import 'package:flutter/material.dart';

class GuideColors{
  List colors = [
    Colors.blueAccent,
    Colors.orangeAccent,
    Colors.pinkAccent,
    Colors.purpleAccent,
    Colors.deepOrangeAccent,
    Colors.indigoAccent,
    Colors.blueAccent,
    Colors.orangeAccent,
    Colors.pinkAccent,
    Colors.purpleAccent,
    Colors.deepOrangeAccent,
    Colors.indigoAccent,
    Colors.blueAccent,
    Colors.orangeAccent,
    Colors.pinkAccent,
    Colors.purpleAccent,
    Colors.deepOrangeAccent,
    Colors.indigoAccent,
    Colors.blueAccent,
    Colors.orangeAccent,
    Colors.pinkAccent,
    Colors.purpleAccent,
    Colors.deepOrangeAccent,
    Colors.indigoAccent
  ];
}